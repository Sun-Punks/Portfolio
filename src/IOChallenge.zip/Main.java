import java.io.*;

public class Main {
  public static void main(String[] args) throws Exception {
    try {
      File fileI = new File("Input.txt");
      File fileO = new File("Output.txt");
      BufferedReader br = new BufferedReader(new FileReader(fileI));
      FileWriter fr = new FileWriter(fileO, true);
      BufferedWriter bw = new BufferedWriter(fr);
      String sr;
      while ((sr = br.readLine()) != null) {
        System.out.println(sr);
        bw.write(sr + " hahaha");
        bw.newLine();
      }

      br.close();
      bw.close();

    }

    catch (IOException e) {
      e.printStackTrace();
    }
  }
}