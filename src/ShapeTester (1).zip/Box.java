public class Box{
  // member variables
  private int l;
  private int w;
  private int h;

  // Constructor
  public Box() {
    l = 0;
    w = 0;
    h = 0;
  }
// Set Method
  public void setL(int l) {
  this.l = l;
}
public void setW(int w){
this.w = w;
  }
public void setH(int h){
  this.h = h;
}
  // Calculation Methods
  public int calcVol() {
    int vol = l*w*h;
    return vol;
    
  }

  public int calcSurfArea() {
    int sa = 2*(l*2 + l*h + w*h);
    return sa;
  }
  }
