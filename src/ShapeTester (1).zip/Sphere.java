public class Sphere{
// Member Variables
  private double r;
  private double pi;

  public Sphere() {
    r = 0.0;
    pi = 3.141592653589;
  }
  public void setR(double r) {
    this.r = r;
  }
  public double calcVol() {
    double vol = (4/3) * pi * Math.pow(r , 3);
    return vol;
  }
  public double calcSurfArea() {
    double sa = 4 * pi * Math.pow(r , 2);
    return sa;
  }
}