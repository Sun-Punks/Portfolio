import java.util.Scanner;


public class Main{
public static void main(String[] args) {
  Scanner scan = new Scanner(System.in);
  Box b1 = new Box();
  Sphere s1 = new Sphere();
  Pyramid p1 = new Pyramid();
  
System.out.println("Welcome to shape tester!");
System.out.println("Please enter box length:");
int val = scan.nextInt();


System.out.println("Please enter box width:");
val = scan.nextInt();

  System.out.println("Please enter box height: ");
    val = scan.nextInt();
  b1.setL(val);
  b1.setH(val);
  b1.setW(val);
  System.out.println("Volume: " + b1.calcVol());
  System.out.println("Surface Area: " + b1.calcSurfArea());

  
System.out.println("Please enter sphere radius:");
int valu = scan.nextInt();

  s1.setR(valu);
  System.out.println("Volume: " + s1.calcVol());
  System.out.println("Surface Area: " + s1.calcSurfArea());


System.out.println("Please enter Pyramid length:");
int value = scan.nextInt();


System.out.println("Please enter Pyramid width:");
value = scan.nextInt();

  System.out.println("Please enter Pyramid height: ");
    value = scan.nextInt();
  
  p1.setL(value);
  p1.setH(value);
  p1.setW(value);
  System.out.println("Volume: " + p1.calcVol());
  System.out.println("Surface Area: " + p1.calcSurfArea());
  }
  }