

import java.io.*;
import java.nio.file.Files;

public class Encrypt {
  public void Encrypt(String word) throws Exception{
    String path = "Input.txt";
    File fileO = new File("Output.txt");
    
    FileWriter fr = new FileWriter(fileO, true);
    BufferedWriter bw = new BufferedWriter(fr);
    char change = ' ';
    String bwrds = " ";
    char[] alphabet = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'A', 'B', 'C', 'D', 'E'};
    int i,a;
    // BufferedReader br = new BufferedReader(new FileReader(word));
    // String sr;
    // while ((sr = br.readLine()) != null) {
    for (i=0; i<word.length(); i++) {
      char letter = word.charAt(i);
      
      //System.out.print(letter + " ");
      
      
      char upLet = Character.toUpperCase(letter);
       //System.out.println(upLet + " ");
      if (new String(alphabet).contains(String.valueOf(upLet))) {
        change = alphabet[new String(alphabet).indexOf(upLet)+5%26];
        //System.out.println(change);
        bwrds = change+bwrds;
      } else {
        //System.out.println("Invalid");
      }
      
      // for(a = 5; a>word.length(); a--){
      //   char n = word.charAt(a);
      //   System.out.println(n + " ");
      // }
    // File.writeString(path, bwrds, fileO);
  }
    System.out.println("Your encrypted word is: " + bwrds);
        bw.write(bwrds);
        bw.newLine();
        bw.close();
  }
}