

import java.util.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

class Main {
  public static void main(String[] args) throws Exception{
    Encrypt e1 = new Encrypt();
    Scanner sc = new Scanner(System.in);
    // ask user to enter word
    System.out.println("Welcome to converter, enter your word: ");

    // store as string
    //String word = sc.nextLine();
    //File fileI = new File("Input.txt");
    // File fileO = new File("Output.txt");
    String path = "Input.txt";
    String word = Files.readString(Paths.get(path));
    

    // show word
    System.out.println("Your starting word is: " + word);
    // BufferedReader br = new BufferedReader(new FileReader(word));
    //   FileWriter fr = new FileWriter(fileO, true);
    //   BufferedWriter bw = new BufferedWriter(fr);
      //String sr;
      //while ((sr = br.readLine()) != null) {
        //System.out.println(sr);
        e1.Encrypt(word);
    // File.writeString(path, bwrds, fileO);
        //bw.newLine();
        //bw.write(e1.bwrds);
      //}
    
    
  }

  // static void en (File word){
  //   char change = ' ';
  //   String bwrds = " ";
  //   char[] alphabet = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'A', 'B', 'C', 'D', 'E'};
  //   int i,a;
  //   BufferedReader br = new BufferedReader(new FileReader(word));
  //   string sr;
  //   while ((sr = br.readLine()) != null) {
  //   for (i=0; i<word.length(); i++) {
  //     char letter = word.charAt(i);
      
  //     //System.out.print(letter + " ");
      
      
  //     char upLet = Character.toUpperCase(letter);
  //      //System.out.println(upLet + " ");
  //     if (new String(alphabet).contains(String.valueOf(upLet))) {
  //       change = alphabet[new String(alphabet).indexOf(upLet)+5%26];
  //       //System.out.println(change);
  //       bwrds = change+bwrds;
  //     } else {
  //       System.out.println("Invalid");
  //     }
      
  //     // for(a = 5; a>word.length(); a--){
  //     //   char n = word.charAt(a);
  //     //   System.out.println(n + " ");
  //     // }
  //   }
  //   }
  //   System.out.println("Your encrypted word is: " + bwrds);
  //}
}