class Merge{
void merge(int a[], int b, int m, int e) {
    int i,j,k;
    int n1 = m-b+1;
    int n2 = e-m;

    int L[] = new int [n1];
    int R[] = new int [n2];

    for(i=0;i<n1;i++){
      L[i]=a[b+i];
    }

    for(j=0;j<n2;j++){
      R[j] = a[m+1+j];
    }

    i=0;
    j=0;
    k=b;

    while (i<n1 && j<n2){
      if(L[i] <= R[j]){
        a[k]=L[i];
        i++;
      } else{
        a[k]=R[j];
        j++;
      }
      k++;
    }

    while(i<n1){
      a[k] = L[i];
      i++;
      k++;
    }

    while (j<n2){
      a[k] = R[j];
      j++;
      k++;
    }
  }

  void mergeSort(int a[], int b, int e){
    if (b<e){
      int m = (b+e)/2;
      mergeSort(a,b,m);
      mergeSort(a,m+1,e);
      merge(a,b,m,e);
    }
  }
  
    void printArray(int a[], int n){
      int i;
      for(i = 0;i<n;i++){
        System.out.print(a[i]+" ");
      }
    }
}