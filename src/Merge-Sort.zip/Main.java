class Main {
  public static void main(String[] args) {
    int a[] = {70,65,99,35,27,58,15,1,65,81,90,60,54,57,85,89,63,25,2,3,13,15,2,6,90,105,250,90,30,35,42,46,48,50,5,57,30,46,70,75,78,40,45,65,56,80,73,22,25,24,50,80,75,79,120,150,165,180};
    int n = a.length;
    Merge m1 = new Merge();
    System.out.println("Before Sorting: ");
    m1.printArray(a,n);
    m1.mergeSort(a,0,n-1);
    System.out.println("\nAfter Sorting: ");
    m1.printArray(a,n);
  }

  // void merge(int a[], int b, int m, int e) {
  //   int i,j,k;
  //   int n1 = m-b+1;
  //   int n2 = r-m;

  //   int L[] = new int [n1];
  //   int R[] = new int [n2];

  //   for(i=0;i<n1;i++){
  //     L[i]=a[b+1];
  //   }

  //   for(j=0;j<n2;j++){
  //     R[j] = a[m+1+j];
  //   }

  //   i=0;
  //   j=0;
  //   k=b;

  //   while (i<n1 && j<n2){
  //     if(L[i] <= R[j]){
  //       a[k]=L[i];
  //       i++;
  //     } else{
  //       a[k]=R[j];
  //       j++;
  //     }
  //     k++;
  //   }

  //   while(i<n1){
  //     a[k] = L[i];
  //     i++;
  //     k++;
  //   }

  //   while (j<n2){
  //     a[k] = R[j];
  //     j++;
  //     k++;
  //   }
  // }

  // void mergeSort(int a[], int b, int e){
  //   if (b<e){
  //     int m = (b+e)/2;
  //     mergeSort(a,b,m);
  //     mergeSort(a,m+1,e);
  //     merge(a,1,m,e);
  //   }
  // }

    // void printArray(int a[], int n){
    //   int i;
    //   for(i = 0;i<n;i++){
    //     System.out.print(a[i]+" ");
    //   }
    // }
  }